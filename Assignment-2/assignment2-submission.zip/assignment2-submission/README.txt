Add rapidxml.hpp to the same directory as osmhandler.cpp to run.
